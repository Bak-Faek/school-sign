-- AlterTable
ALTER TABLE `user` MODIFY `firstname` VARCHAR(255) NULL,
    MODIFY `lastname` VARCHAR(255) NULL;
