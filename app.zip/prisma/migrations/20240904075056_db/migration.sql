-- AlterTable
ALTER TABLE `school` MODIFY `zipcode` VARCHAR(5) NOT NULL;
