export interface CardEl {
  name: string;
}

export interface CardElProps {
  elements: CardEl[];
}
