import SchoolLogin from "@/components/forms/SchoolLogin";

export default function LoginPageSchool() {
  return (
    <>
      <div className="flex items-center justify-center h-screen">
        <SchoolLogin />
      </div>
    </>
  );
}
